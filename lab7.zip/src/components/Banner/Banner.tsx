import React from 'react';
import { ButtonLink } from '../Button/ButtonLink';
import classes from './Banner.module.css'

export const Banner: React.FC = (props) => {
    return (
            <section style={{backgroundImage: 'url('+ props.BgImage + ')' }} className={classes.banner}>
                <div className={classes.wrapper}>
                    <div className={classes.text}>
                        <h2>{props.Title}</h2>
                        <p>{props.Subtitle}</p>
                    </div>
                    
                    <ButtonLink Ref={props.Link}>{props.ButtTitle}</ButtonLink>
                    

                </div>
            </section>
    );
}