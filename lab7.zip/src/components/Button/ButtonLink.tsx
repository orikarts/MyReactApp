import classes from './ButtonLink.module.css'

export const ButtonLink: React.FC = (props) => {
    return (
        <div className={classes.butt}>
    <a href={props.Ref}>{props.children}</a>
</div>

    );
}