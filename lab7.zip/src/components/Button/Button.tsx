import classes from './Button.module.css'

export const Button: React.FC = (props) => {
    return (
        <button id={props.ID} onClick={props.clickEvent} className={classes.butt}>
            {props.children}
        </button>
    );
}